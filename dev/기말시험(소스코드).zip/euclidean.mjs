function euclidean(num1, num2) {
        while(num2 != 0) {
            let r = num1 % num2;
            num1 = num2;
            num2 = r;
        } // while
    return num1;
} // euclidean

console.log(euclidean(78,66));

